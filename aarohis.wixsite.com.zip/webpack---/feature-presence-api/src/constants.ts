export const CHAT_APP_DEF_ID = '14517e1a-3ff0-af98-408e-2bd6953c36a2'
export const PRESENCE_API_EXPERIMENT = 'specs.thunderbolt.presenceApi'
export const PRESENCE_WITHOUT_CHAT_EXPERIMENT = 'specs.thunderbolt.presenceWithoutChat'
export const LAZY_PRESENCE_TIMEOUT = 1000 * 5
