export const PasswordProtectedPageApiSymbol = Symbol('PasswordProtectedPageApi')
export const name = 'passwordProtectedPage' as const

export const DialogComponentId = 'SM_ROOT_COMP'
