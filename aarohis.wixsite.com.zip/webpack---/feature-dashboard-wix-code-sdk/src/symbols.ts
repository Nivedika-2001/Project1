export const name = 'dashboardWixCodeSdk' as const
export const namespace = 'dashboard' as const
