export const name = 'consentPolicy' as const

export const ConsentPolicySymbol = Symbol('ConsentPolicy')
