export const namespace = 'authentication' as const
export const name = 'authenticationWixCodeSdk' as const

export const dialogFeatureName = 'authentication' as const
export const AuthenticationApiSymbol = Symbol('AuthenticationApi')
