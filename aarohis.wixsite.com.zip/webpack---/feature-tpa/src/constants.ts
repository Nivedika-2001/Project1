export const TPA_COMPONENTS = ['TPASection', 'TPAMultiSection', 'TPAGluedWidget', 'TPAWidget']
