export const isIOS = (): boolean => /\(iP(hone|ad|od);/i.test(window?.navigator?.userAgent)
