export const SsrLoggerSymbol = Symbol('SsrLogger')
