export const name = 'scrollRestoration' as const

export const ScrollRestorationAPISymbol = Symbol('ScrollRestorationAPISymbol')
