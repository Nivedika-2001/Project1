export const name = 'platform' as const
export const PlatformInitializerSym = Symbol.for('PlatformInitializer')
export const UnfinishedTasksManagerSymbol = Symbol('UnfinishedTasksHandlers')
