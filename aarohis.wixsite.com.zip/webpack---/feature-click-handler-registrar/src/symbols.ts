export const name = 'clickHandlerRegistrar' as const
export const PreviewTooltipCallbackSymbol = Symbol('PreviewTooltipCallback')
export const OnLinkClick = Symbol('OnLinkClick')
